/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_496(unsigned *p)
{
    *p = 2496104776U;
}

unsigned getval_277()
{
    return 3284633928U;
}

unsigned addval_497(unsigned x)
{
    return x + 3284633928U;
}

void setval_467(unsigned *p)
{
    *p = 1481627090U;
}

unsigned addval_206(unsigned x)
{
    return x + 3281096792U;
}

unsigned getval_465()
{
    return 2421696843U;
}

unsigned addval_214(unsigned x)
{
    return x + 3281031384U;
}

unsigned addval_375(unsigned x)
{
    return x + 2496104776U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_195()
{
    return 3353381192U;
}

void setval_499(unsigned *p)
{
    *p = 3281043849U;
}

void setval_318(unsigned *p)
{
    *p = 3223377577U;
}

void setval_262(unsigned *p)
{
    *p = 2428603158U;
}

unsigned addval_489(unsigned x)
{
    return x + 2425408136U;
}

unsigned getval_193()
{
    return 3221804681U;
}

unsigned getval_310()
{
    return 3286272329U;
}

unsigned addval_359(unsigned x)
{
    return x + 3804482187U;
}

unsigned getval_446()
{
    return 3285584183U;
}

unsigned getval_151()
{
    return 3353381192U;
}

void setval_252(unsigned *p)
{
    *p = 2425411208U;
}

unsigned addval_377(unsigned x)
{
    return x + 3374372521U;
}

void setval_495(unsigned *p)
{
    *p = 3247159480U;
}

unsigned getval_121()
{
    return 2447411528U;
}

void setval_157(unsigned *p)
{
    *p = 3375415689U;
}

unsigned addval_221(unsigned x)
{
    return x + 2497743176U;
}

unsigned getval_220()
{
    return 3267463650U;
}

unsigned addval_315(unsigned x)
{
    return x + 2496301313U;
}

unsigned addval_218(unsigned x)
{
    return x + 3281046153U;
}

unsigned addval_278(unsigned x)
{
    return x + 3374367105U;
}

unsigned addval_350(unsigned x)
{
    return x + 2430634312U;
}

void setval_317(unsigned *p)
{
    *p = 3286272328U;
}

void setval_476(unsigned *p)
{
    *p = 3531921033U;
}

unsigned addval_249(unsigned x)
{
    return x + 3227566473U;
}

unsigned getval_140()
{
    return 3372799689U;
}

unsigned getval_480()
{
    return 818006665U;
}

unsigned getval_389()
{
    return 3674786441U;
}

unsigned getval_133()
{
    return 3599295417U;
}

unsigned getval_474()
{
    return 2445969860U;
}

void setval_333(unsigned *p)
{
    *p = 2447411528U;
}

unsigned getval_248()
{
    return 3677929865U;
}

unsigned addval_219(unsigned x)
{
    return x + 1807993545U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
