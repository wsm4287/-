/* Quiz 1 - Prob. 1 */

#include <stdio.h>
#include <stdlib.h>
// Function to  sort a given array. Use one of bubble sort/selection sort/insertion sort.
void mySort(int *arr, int size){
    int i,j;
    int x;
    for(i=0; i<size; i++){
        for(j=0; j<size-i-1; j++){
            if(arr[j] > arr[j+1]){
                x = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = x;

            }
        }
    }


}

// Function to check if array has 2 elements whose sum is equal to the given value
int checkSumofPair(int *arr, int arr_size, int sum){
    int i,j;
    i=0;
    j=arr_size;
    while(1){
        if(arr[i] + arr[j] > sum){
            j--;
        }
        else if(arr[i] + arr[j] <sum){
            i++;
        }
        else
            break;
        if(i>j)
            return 0;

    }



}

// Function to print an array
void print(int *arr, int n){
    int i;
    for(i=0; i<n; i++)
        printf("%d ", arr[i]);
    printf("\n");

}


int main()
{
    int size,n;

    scanf("%d",&size);
    int *ar=(int*)malloc(sizeof(int)*size);
    for(int i=0;i<size;i++)
        scanf("%d",&ar[i]);
    scanf("%d",&n);
    printf("\n\n");

    printf("Entered Array : ");
    print(ar,size);

    mySort(ar,size);

    //check for mySort() function
    printf("Sorted Array : ");
    print(ar,size);

    // check for checkSumofPair() function
    if (checkSumofPair(ar, size, n))
        printf("Array has two elements with given sum");
    else
        printf("Array doesn't have two elements with given sum");

    return 0;
}
