void print_result(int, int, int, int, int);
